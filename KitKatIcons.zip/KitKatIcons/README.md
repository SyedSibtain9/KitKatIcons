# KitKat Icons (icon pack)
Icons come from the XDA KitKat packs (V2). Already mapped for common Google/Nothing apps via acts.txt.
- More apps: add PNGs to icons/ named by package, run `python3 gen.py` with phone on ADB (auto-detects activities).
- Build: push to GitHub -> Actions -> Build APK -> download artifact (or Android Studio).
- Install APK, then pick "KitKat Icons" in your launcher's icon pack setting.
- Adding apps: open the pack app, tap "Share app list", add lines to acts.txt, drop PNGs in icons/ (or draw with tools/make_icons.py), then run gen.py.

## Credits
- Base icons: KitKat icon packs by Tony_stark_noob (XDA).
- Sharper KitKat 4.4 icons (Chrome, Calendar, Camera, Clock, Phone, Play Store, Google, Gmail, ...): "KitKat HD theme" launcher theme.
- Remaining icons drawn in KitKat style with tools/make_icons.py.
Icons belong to their original authors; ask permission before publishing.
