# KitKat Icons (icon pack)
Icons come from the XDA KitKat packs (V2). Already mapped for common Google/Nothing apps via acts.txt.
- More apps: add PNGs to icons/ named by package, run `python3 gen.py` with phone on ADB (auto-detects activities).
- Build: push to GitHub -> Actions -> Build APK -> download artifact (or Android Studio).
- Install APK, then pick "KitKat Icons" in your launcher's icon pack setting.
- Adding apps: open the pack's app, tap "Share app list", send me the text (or paste into acts.txt).
