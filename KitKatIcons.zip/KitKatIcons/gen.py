#!/usr/bin/env python3
"""Build appfilter.xml from icons/<package.name>.png.
Usage: python3 gen.py            (reads launcher activities from a connected phone via adb)
       python3 gen.py acts.txt   (or from a file with lines like com.pkg/.Activity)
"""
import os, re, shutil, subprocess, sys
root = os.path.dirname(os.path.abspath(__file__))
icons = os.path.join(root, "icons")
res = os.path.join(root, "app/src/main/res")
if len(sys.argv) > 1:
    raw = open(sys.argv[1]).read()
else:
    try:
        raw = subprocess.check_output(["adb", "shell", "cmd", "package", "query-activities", "--brief",
            "-a", "android.intent.action.MAIN", "-c", "android.intent.category.LAUNCHER"], text=True)
    except Exception:
        print("adb not available, using acts.txt")
        raw = open(os.path.join(root, "acts.txt")).read()
comps = set()
for line in raw.splitlines():
    if "priority" in line:
        continue
    m = re.search(r"([\w.]+)/([\w.$]+)", line)
    if m:
        pkg, act = m.groups()
        if act.startswith("."):
            act = pkg + act
        comps.add((pkg, act))
os.makedirs(res + "/drawable-nodpi", exist_ok=True)
items, names = [], []
for pkg, act in sorted(comps):
    src = os.path.join(icons, pkg + ".png")
    if not os.path.exists(src):
        continue
    name = "kk_" + re.sub(r"\W", "_", pkg).lower()
    shutil.copy(src, f"{res}/drawable-nodpi/{name}.png")
    items.append(f'    <item component="ComponentInfo{{{pkg}/{act}}}" drawable="{name}" />')
    names.append(name)
if names:
    shutil.copy(f"{res}/drawable-nodpi/{names[0]}.png", f"{res}/drawable-nodpi/kk_preview.png")
head = '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
xml = head + '    <scale factor="1.0" />\n' + "\n".join(items) + "\n</resources>\n"
open(res + "/xml/appfilter.xml", "w").write(xml)
open(root + "/app/src/main/assets/appfilter.xml", "w").write(xml)
open(root + "/app/src/main/assets/drawable.xml", "w").write(
    head + "    <version>1</version>\n" + "\n".join(f'    <item drawable="{n}" />' for n in names) + "\n</resources>\n")
print(f"mapped {len(names)} icons of {len(comps)} launcher activities")
