package com.syed.kitkaticons;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        PackageManager pm = getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(launcher, 0);

        List<String> lines = new ArrayList<>();
        for (ResolveInfo r : apps) {
            String label = r.loadLabel(pm).toString();
            lines.add(r.activityInfo.packageName + "/" + r.activityInfo.name + "  # " + label);
        }
        Collections.sort(lines);
        final StringBuilder sb = new StringBuilder();
        for (String l : lines) sb.append(l).append("\n");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 96, 48, 48);

        TextView title = new TextView(this);
        title.setTextSize(20);
        title.setText("KitKat Icons\n\nPick this pack in your launcher settings.\n" + lines.size() + " apps found.");
        root.addView(title);

        Button share = new Button(this);
        share.setText("Share app list");
        share.setOnClickListener(v -> {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, sb.toString());
            startActivity(Intent.createChooser(send, "Share app list"));
        });
        root.addView(share);

        ScrollView scroll = new ScrollView(this);
        TextView list = new TextView(this);
        list.setTextSize(11);
        list.setTextIsSelectable(true);
        list.setText(sb.toString());
        scroll.addView(list);
        root.addView(scroll);

        setContentView(root);
    }
}
