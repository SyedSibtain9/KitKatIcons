package com.syed.kitkaticons;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setPadding(48, 96, 48, 48);
        tv.setTextSize(18);
        tv.setText("KitKat Icons\n\nOpen your launcher settings and pick this icon pack.");
        setContentView(tv);
    }
}
