package com.syed.kitkaticons;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {

    private float density;

    private int dp(int v) {
        return Math.round(v * density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;

        // draw behind the status and navigation bars
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        // collect the installed apps (kept hidden, only used for the share button)
        PackageManager pm = getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(launcher, 0);
        List<String> lines = new ArrayList<>();
        for (ResolveInfo r : apps) {
            String label = r.loadLabel(pm).toString();
            lines.add(r.activityInfo.packageName + "/" + r.activityInfo.name + "  # " + label);
        }
        Collections.sort(lines);
        StringBuilder sb = new StringBuilder();
        for (String l : lines) sb.append(l).append("\n");
        final String appList = sb.toString();

        FrameLayout root = new FrameLayout(this);
        root.addView(new GlowBackground(this),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        root.addView(scroll,
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(dp(24), dp(56), dp(24), dp(40));
        scroll.addView(col, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // keep content clear of the status bar / navigation bar
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            col.setPadding(dp(24), insets.getSystemWindowInsetTop() + dp(32),
                    dp(24), insets.getSystemWindowInsetBottom() + dp(32));
            return insets;
        });

        // pack icon
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.kk_preview);
        icon.setBackground(glass(32, 0x26FFFFFF));
        icon.setPadding(dp(20), dp(20), dp(20), dp(20));
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        col.addView(icon, new LinearLayout.LayoutParams(dp(112), dp(112)));

        TextView title = text("KitKat Icons", 30, Color.WHITE, true);
        LinearLayout.LayoutParams tlp = lp(0, 20, 0, 0);
        col.addView(title, tlp);

        TextView sub = text("Nostalgic KitKat-style icons for your launcher", 15, 0xBFFFFFFF, false);
        sub.setGravity(Gravity.CENTER);
        col.addView(sub, lp(0, 6, 0, 0));

        TextView chip = text(lines.size() + " apps detected", 13, Color.WHITE, true);
        chip.setBackground(glass(20, 0x2EFFFFFF));
        chip.setPadding(dp(16), dp(7), dp(16), dp(7));
        col.addView(chip, lp(0, 18, 0, 0));

        // how-to card
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(glass(24, 0x24FFFFFF));
        card.setPadding(dp(20), dp(18), dp(20), dp(10));
        card.addView(text("How to apply", 16, Color.WHITE, true));
        String[] steps = {"Open your launcher settings", "Choose Icon pack", "Select KitKat Icons"};
        for (int i = 0; i < steps.length; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView num = text(String.valueOf(i + 1), 13, 0xFF0B3FD0, true);
            num.setGravity(Gravity.CENTER);
            GradientDrawable dot = new GradientDrawable();
            dot.setShape(GradientDrawable.OVAL);
            dot.setColor(Color.WHITE);
            num.setBackground(dot);
            row.addView(num, new LinearLayout.LayoutParams(dp(26), dp(26)));
            TextView t = text(steps[i], 15, 0xE6FFFFFF, false);
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tl.leftMargin = dp(12);
            row.addView(t, tl);
            card.addView(row, lp(0, 12, 0, 4));
        }
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.topMargin = dp(26);
        col.addView(card, cardLp);

        // share button
        LinearLayout share = new LinearLayout(this);
        share.setOrientation(LinearLayout.HORIZONTAL);
        share.setGravity(Gravity.CENTER);
        share.setBackground(glass(30, Color.WHITE));
        share.setClickable(true);
        ImageView shareIcon = new ImageView(this);
        shareIcon.setImageResource(R.drawable.ic_share);
        share.addView(shareIcon, new LinearLayout.LayoutParams(dp(22), dp(22)));
        TextView shareText = text("Share app list", 16, 0xFF0B3FD0, true);
        LinearLayout.LayoutParams stl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stl.leftMargin = dp(10);
        share.addView(shareText, stl);
        share.setOnClickListener(v -> {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, appList);
            startActivity(Intent.createChooser(send, "Share app list"));
        });
        LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(60));
        shareLp.topMargin = dp(28);
        col.addView(share, shareLp);

        TextView hint = text("Missing an icon? Share your app list so it can be added.", 12, 0x99FFFFFF, false);
        hint.setGravity(Gravity.CENTER);
        col.addView(hint, lp(0, 14, 0, 0));

        setContentView(root);
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        return t;
    }

    private LinearLayout.LayoutParams lp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private GradientDrawable glass(int radiusDp, int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (fill != Color.WHITE) g.setStroke(Math.max(1, dp(1)), 0x40FFFFFF);
        return g;
    }

    /** Soft blurred blue glow background (no real blur needed, works on every Android version). */
    static class GlowBackground extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        GlowBackground(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            p.setShader(new LinearGradient(0, 0, 0, h,
                    new int[]{0xFF061338, 0xFF0B2A78, 0xFF1246C9}, null, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            glow(c, w * 0.12f, h * 0.10f, w * 0.90f, 0x4DA3FF, 0xA0);
            glow(c, w * 0.95f, h * 0.42f, w * 0.75f, 0x2F6BFF, 0x99);
            glow(c, w * 0.20f, h * 0.88f, w * 0.95f, 0x00C2FF, 0x66);
            glow(c, w * 0.85f, h * 0.98f, w * 0.65f, 0x7A5CFF, 0x66);
        }

        private void glow(Canvas c, float cx, float cy, float r, int rgb, int alpha) {
            p.setShader(new RadialGradient(cx, cy, r, (alpha << 24) | rgb, rgb, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
        }
    }
}
