#!/usr/bin/env python3
"""Draws KitKat-style icons (soft shadow, top light, gloss) into ../icons/<package>.png
Needs: pip install cairosvg pillow
Usage: python3 tools/make_icons.py            (all)
       python3 tools/make_icons.py com.whatsapp com.snapchat.android   (some)
"""
import io, math, os, sys
import cairosvg
from PIL import Image, ImageChops, ImageFilter

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "icons")
D = {}
_n = [0]


def icon(*pkgs):
    def deco(f):
        for p in pkgs:
            D[p] = f
        return f
    return deco


def _soft(top, bot, k=.5):
    t = [int(top[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(bot[i:i + 2], 16) for i in (1, 3, 5)]
    m = [(x + y) / 2 for x, y in zip(t, b)]
    f = lambda v: "#%02x%02x%02x" % tuple(max(0, min(255, round(c))) for c in v)
    return f([mc + (x - mc) * k for mc, x in zip(m, t)]), f([mc + (y - mc) * k for mc, y in zip(m, b)])


def vg(i, top, bot, ys=(24, 168)):
    top, bot = _soft(top, bot) if top.startswith("#") and bot.startswith("#") and len(top) == 7 and len(bot) == 7 else (top, bot)
    return (f'<linearGradient id="{i}" gradientUnits="userSpaceOnUse" x1="0" y1="{ys[0]}" x2="0" y2="{ys[1]}">'
            f'<stop offset="0" stop-color="{top}"/><stop offset="1" stop-color="{bot}"/></linearGradient>')


def fill(shape, f, extra=""):
    return shape.replace("/>", f' fill="{f}" {extra}/>', 1)


def shine(shape, y0=24, y1=100, op=.42):
    return "", ""
    _n[0] += 1
    i = _n[0]
    d = (f'<clipPath id="c{i}">{shape}</clipPath>'
         f'<linearGradient id="s{i}" gradientUnits="userSpaceOnUse" x1="0" y1="{y0}" x2="0" y2="{y1}">'
         f'<stop offset="0" stop-color="#fff" stop-opacity="{op}"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>')
    b = f'<g clip-path="url(#c{i})"><rect x="0" y="{y0}" width="192" height="{y1 - y0}" fill="url(#s{i})"/></g>'
    return d, b


def solid(shape, top, bot, ys=(24, 168), op=.42, gloss=True, extra=""):
    _n[0] += 1
    gid = f"g{_n[0]}"
    d = vg(gid, top, bot, ys)
    b = fill(shape, f"url(#{gid})", extra)
    if gloss:
        sd, sb = shine(shape, ys[0], ys[0] + (ys[1] - ys[0]) * .55, op)
        d += sd
        b += sb
    return d, b


def raw(s):
    return "", s


def P(*parts):
    return "".join(p[0] for p in parts), "".join(p[1] for p in parts)


def text(x, y, s, size, fill="#fff", weight="bold", family="DejaVu Sans", style="normal", anchor="middle"):
    return (f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{weight}" font-style="{style}" '
            f'font-family="{family}" text-anchor="{anchor}" fill="{fill}">{s}</text>')


SQ = '<rect x="24" y="24" width="144" height="144" rx="22"/>'
CI = '<circle cx="96" cy="96" r="72"/>'
HANDSET = ("M24 14 C16 14 10 22 12 34 C16 62 38 84 66 88 C78 90 86 84 86 76 L86 68 C86 64 83 61 80 60 "
           "L68 56 C65 55 62 56 60 58 L56 63 C48 60 40 52 37 44 L42 40 C44 38 45 35 44 32 L40 20 C39 16 36 14 32 14 Z")


def star(cx, cy, ro, ri, n=5, rot=-90):
    pts = []
    for k in range(n * 2):
        r = ro if k % 2 == 0 else ri
        a = math.radians(rot + k * 180 / n)
        pts.append(f"{cx + r * math.cos(a):.1f},{cy + r * math.sin(a):.1f}")
    return " ".join(pts)


def landscape(sky1, sky2, hill1, hill2, frame="#fff"):
    d = vg("sky", sky1, sky2, (30, 150)) + vg("h1", hill1, hill2, (90, 150)) + vg("h2", hill2, hill1, (100, 150))
    clip = '<rect x="32" y="40" width="128" height="112" rx="14"/>'
    sd, sb = shine(clip, 40, 100, .3)
    body = (f'<clipPath id="lc">{clip}</clipPath><g clip-path="url(#lc)">'
            '<rect x="30" y="38" width="132" height="116" fill="url(#sky)"/>'
            '<circle cx="132" cy="70" r="12" fill="#fff6c8"/>'
            '<path d="M20 140 L70 82 L104 124 L124 100 L172 150 L172 160 L20 160 Z" fill="url(#h1)"/>'
            '<path d="M20 152 L56 120 L96 150 L140 118 L172 144 L172 160 L20 160 Z" fill="url(#h2)" opacity=".9"/>'
            '</g>' + sb +
            f'<rect x="32" y="40" width="128" height="112" rx="14" fill="none" stroke="{frame}" stroke-width="8"/>')
    return d + sd + '<clipPath id="lc2"></clipPath>', body


# ----------------------------------------------------------------------------- messaging / social
@icon("com.whatsapp")
def _():
    bub = '<path d="M96 28 C130 28 158 54 158 90 C158 126 130 152 96 152 C86 152 77 150 69 146 L38 160 L48 130 C38 119 34 106 34 90 C34 54 62 28 96 28 Z"/>'
    return P(solid(bub, "#72f27f", "#14982f", (28, 160)),
             raw(f'<g transform="translate(55 49) scale(.82)"><path d="{HANDSET}" fill="#fff"/></g>'))


@icon("com.snapchat.android")
def _():
    ghost = ("M96 38 C74 38 68 56 70 78 C70 84 66 88 58 90 C62 96 68 99 70 103 C66 112 56 116 50 120 "
             "C56 126 66 126 72 128 C74 132 74 140 82 140 C88 140 92 136 96 136 C100 136 104 140 110 140 "
             "C118 140 118 132 120 128 C126 126 136 126 142 120 C136 116 126 112 122 103 C124 99 130 96 134 90 "
             "C126 88 122 84 122 78 C124 56 118 38 96 38 Z")
    return P(solid(SQ, "#fffc3a", "#f5d300", op=.5),
             raw(f'<path d="{ghost}" fill="#fff" stroke="#111" stroke-width="5" stroke-linejoin="round"/>'
                 '<ellipse cx="84" cy="82" rx="5" ry="8" fill="#111"/><ellipse cx="108" cy="82" rx="5" ry="8" fill="#111"/>'))


@icon("com.instagram.android")
def _():
    body = '<rect x="30" y="50" width="132" height="108" rx="18"/>'
    stripes = "".join(f'<rect x="30" y="{64 + k * 7}" width="132" height="7" fill="{c}"/>'
                      for k, c in enumerate(["#e53935", "#fb8c00", "#fdd835", "#43a047", "#1e88e5"]))
    return P(raw(vg("lens", "#4a4a4a", "#050505", (70, 150))),
             solid(body, "#f1dcb2", "#b8975f", (50, 158), .35),
             raw(f'<clipPath id="bc">{body}</clipPath><g clip-path="url(#bc)">{stripes}</g>'
                 '<rect x="116" y="36" width="34" height="18" rx="5" fill="#d9bf8f"/>'
                 '<circle cx="96" cy="112" r="38" fill="#2a2118"/><circle cx="96" cy="112" r="32" fill="url(#lens)"/>'
                 '<circle cx="96" cy="112" r="18" fill="#10213a"/><circle cx="88" cy="104" r="6" fill="#fff" opacity=".7"/>'))


@icon("com.twitter.android")
def _():
    return P(solid(SQ, "#3b3b3b", "#050505", op=.35),
             raw('<polygon points="58,54 80,54 136,138 114,138" fill="#fff"/>'
                 '<line x1="134" y1="54" x2="58" y2="138" stroke="#fff" stroke-width="6" stroke-linecap="round"/>'))


@icon("org.thunderdog.challegram")
def _():
    plane = "M42 92 L148 50 C153 48 157 52 155 57 L130 148 C129 153 123 154 120 150 L98 124 L78 142 C75 144 72 142 72 139 L71 112 L43 101 C39 99 39 94 42 92 Z"
    return P(solid(CI, "#4fc3f7", "#1581c0", op=.4),
             raw(f'<path d="{plane}" fill="#fff"/><path d="M71 112 L136 66 L98 124 Z" fill="#c4d9e8"/>'))


@icon("com.y99.chat")
def _():
    bub = '<path d="M96 30 C132 30 160 54 160 88 C160 122 132 146 96 146 C88 146 80 145 73 142 L44 158 L52 128 C40 118 32 104 32 88 C32 54 60 30 96 30 Z"/>'
    return P(solid(bub, "#ff74b0", "#c2185b", (30, 160)), raw(text(96, 108, "99", 52)))


@icon("com.testyentra.qtalk")
def _():
    return P(solid(SQ, "#4aa3f5", "#1558c4", op=.45),
             raw('<path d="M66 50 H126 C140 50 150 60 150 74 V104 C150 118 140 128 126 128 H98 L70 150 L72 128 H66 C52 128 42 118 42 104 V74 C42 60 52 50 66 50 Z" fill="#fff"/>'
                 + text(96, 112, "Q", 54, "#1c63c9")))


@icon("com.plato.android")
def _():
    dots = "".join(f'<circle cx="{x}" cy="{y}" r="7" fill="#5b2bb5"/>' for x, y in
                   [(76, 76), (116, 76), (96, 96), (76, 116), (116, 116)])
    return P(solid(SQ, "#9b6bff", "#5226b8", op=.45),
             raw('<rect x="54" y="54" width="84" height="84" rx="18" fill="#fff"/>' + dots))


# ----------------------------------------------------------------------------- google
@icon("com.google.android.youtube")
def _():
    rr = '<rect x="22" y="48" width="148" height="100" rx="30"/>'
    return P(solid(rr, "#ff5348", "#c4120a", (48, 148), .5),
             raw('<polygon points="80,74 128,98 80,122" fill="#fff"/>'))


@icon("com.google.android.apps.photos")
def _():
    petal = "M96 96 L96 70 A26 26 0 0 1 122 44 L148 44 L148 70 A26 26 0 0 1 122 96 Z"
    cols = [("#f4544a", "#c4251c"), ("#fbc02d", "#e09400"), ("#36b258", "#16883a"), ("#4a8ff7", "#1d5ed1")]
    d, b = "", ""
    for k, (c1, c2) in enumerate(cols):
        d += vg(f"p{k}", c1, c2, (30, 160))
        b += f'<g transform="rotate({k * 90} 96 96) translate(-6 -6)"><path d="{petal}" fill="url(#p{k})" opacity=".95"/></g>'
    b = f'<g transform="translate(96 96) scale(1.18) translate(-96 -96)">{b}</g>'
    return d, b


@icon("com.google.android.apps.bard")
def _():
    st = "M96 28 C100 68 124 92 164 96 C124 100 100 124 96 164 C92 124 68 100 28 96 C68 92 92 68 96 28 Z"
    d = ('<linearGradient id="gm" gradientUnits="userSpaceOnUse" x1="40" y1="40" x2="160" y2="160">'
         '<stop offset="0" stop-color="#4b8ef7"/><stop offset=".5" stop-color="#9b72cb"/><stop offset="1" stop-color="#e0606f"/></linearGradient>')
    sd, sb = shine(f'<path d="{st}"/>', 28, 100, .35)
    return d + sd, f'<path d="{st}" fill="url(#gm)"/>' + sb


@icon("com.google.android.apps.subscriptions.red")
def _():
    one = [(62, 92), (108, 48), (130, 48), (130, 152), (104, 152), (104, 86), (80, 108)]
    poly = " ".join(f"{x},{y}" for x, y in one)
    return P(solid(CI, "#ffffff", "#dfe3e8", op=.0),
             raw(f'<clipPath id="one"><polygon points="{poly}"/></clipPath><g clip-path="url(#one)">'
                 '<rect x="50" y="40" width="54" height="64" fill="#4285f4"/><rect x="104" y="40" width="40" height="64" fill="#ea4335"/>'
                 '<rect x="50" y="104" width="54" height="56" fill="#fbbc04"/><rect x="104" y="104" width="40" height="56" fill="#34a853"/></g>'))


@icon("com.google.android.keep")
def _():
    note = "M50 28 H142 A14 14 0 0 1 156 42 V120 L112 164 H50 A14 14 0 0 1 36 150 V42 A14 14 0 0 1 50 28 Z"
    return P(solid(f'<path d="{note}"/>', "#ffdc5c", "#f5a300", (28, 164), .4),
             raw('<path d="M112 164 V134 A14 14 0 0 1 126 120 H156 Z" fill="#c98200" opacity=".85"/>'
                 '<circle cx="96" cy="84" r="28" fill="#fff"/><rect x="82" y="108" width="28" height="16" rx="4" fill="#e6e6e6"/>'
                 '<path d="M90 104 L90 92 M102 104 L102 92 M90 92 Q96 80 102 92" stroke="#f5a300" stroke-width="4" fill="none" stroke-linecap="round"/>'))


@icon("com.google.android.apps.wallpaper")
def _():
    return landscape("#7fd0ff", "#2a79e0", "#2fa36b", "#0f6b45")


@icon("com.bnyro.wallpaper")
def _():
    return landscape("#ffb6d9", "#8a4be0", "#7e57c2", "#3a1d8c")


@icon("com.google.android.apps.safetyhub")
def _():
    sh = '<path d="M96 26 L158 50 V96 C158 132 132 156 96 168 C60 156 34 132 34 96 V50 Z"/>'
    lines = "".join(f'<line x1="{96 - 24 * math.cos(math.radians(a))}" y1="{98 - 24 * math.sin(math.radians(a))}" '
                    f'x2="{96 + 24 * math.cos(math.radians(a))}" y2="{98 + 24 * math.sin(math.radians(a))}" '
                    'stroke="#fff" stroke-width="10" stroke-linecap="round"/>' for a in (90, 30, 150))
    return P(solid(sh, "#5a9cf5", "#1a55c2", (26, 168), .45), raw(lines))


# ----------------------------------------------------------------------------- AI
@icon("com.openai.chatgpt")
def _():
    loops = "".join(f'<rect x="78" y="34" width="36" height="66" rx="18" transform="rotate({k * 60} 96 96) rotate(-24 96 67)" '
                    'fill="none" stroke="#fff" stroke-width="8"/>' for k in range(6))
    return P(solid(CI, "#2fd1a0", "#0b7a5c", op=.4), raw(f'<g transform="translate(96 96) scale(.82) translate(-96 -96)">{loops}</g>'))


@icon("com.anthropic.claude")
def _():
    lens = [46, 30, 42, 28, 46, 32, 40, 30, 46, 28, 42, 32]
    ls = "".join(f'<line x1="96" y1="96" x2="{96 + L * math.cos(math.radians(k * 30 - 90)):.1f}" '
                 f'y2="{96 + L * math.sin(math.radians(k * 30 - 90)):.1f}" stroke="#fcefe4" stroke-width="10" stroke-linecap="round"/>'
                 for k, L in enumerate(lens))
    return P(solid(SQ, "#e8946f", "#bf5c35", op=.45), raw(ls))


# ----------------------------------------------------------------------------- music / media / browsers
@icon("com.apple.android.music")
def _():
    note = "M72 48 L142 34 V120 A20 16 -15 1 1 134 106 V70 L80 84 V138 A20 16 -15 1 1 72 124 Z"
    return P(solid(SQ, "#ff6584", "#e01238", op=.5), raw(f'<path d="{note}" fill="#fff"/>'))


@icon("com.opera.browser")
def _():
    ring = '<path fill-rule="evenodd" d="M96 26 A70 70 0 1 1 96 166 A70 70 0 1 1 96 26 Z M96 52 C80 52 70 70 70 96 C70 122 80 140 96 140 C112 140 122 122 122 96 C122 70 112 52 96 52 Z"/>'
    return P(solid(ring, "#ff6a70", "#b3001e", (26, 166), .5))


@icon("org.videolan.vlc")
def _():
    def xl(y): return 82 + (48 - 82) * (y - 40) / 98
    def xr(y): return 110 + (144 - 110) * (y - 40) / 98
    band = lambda a, b: f'<polygon points="{xl(a):.1f},{a} {xr(a):.1f},{a} {xr(b):.1f},{b} {xl(b):.1f},{b}" fill="#fff"/>'
    cone = '<path d="M82 42 L110 42 L146 140 L46 140 Z" stroke-linejoin="round" stroke="#e86a00" stroke-width="6"/>'
    return P(solid('<rect x="34" y="136" width="124" height="24" rx="8"/>', "#ffa534", "#d96400", (136, 160), .3),
             solid(cone, "#ffb347", "#ee6c00", (40, 140), .3),
             raw(band(70, 88) + band(102, 120)))


@icon("com.lastwave.app")
def _():
    hs = [30, 56, 84, 62, 100, 70, 44, 24]
    bars = "".join(f'<rect x="{42 + k * 14}" y="{96 - h / 2}" width="9" height="{h}" rx="4.5" fill="#d9c2ff"/>' for k, h in enumerate(hs))
    return P(solid(SQ, "#7b4fc4", "#2e1558", op=.4), raw(bars))


@icon("com.music.bitchord")
def _():
    return P(solid(SQ, "#2a3b66", "#0c1426", op=.35),
             raw('<ellipse cx="80" cy="128" rx="22" ry="16" transform="rotate(-20 80 128)" fill="#38e1ff"/>'
                 '<rect x="94" y="50" width="11" height="80" rx="3" fill="#38e1ff"/>'
                 '<path d="M105 50 C128 58 146 74 138 102 C134 86 122 80 105 76 Z" fill="#7dedff"/>'))


@icon("com.nuvio.app")
def _():
    return P(solid(CI, "#c05cf7", "#5a1fb8", op=.45), raw('<polygon points="78,64 132,96 78,128" fill="#fff"/>'))


@icon("in.startv.hotstar")
def _():
    return P(solid(CI, "#2a3f9c", "#0a1033", op=.4),
             raw(f'<polygon points="{star(96, 98, 42, 17)}" fill="#fff"/>'
                 '<circle cx="96" cy="96" r="60" fill="none" stroke="#fff" stroke-opacity=".35" stroke-width="3"/>'))


@icon("app.netmirror.netmirrornew")
def _():
    return P(solid(SQ, "#3a3a3a", "#050505", op=.35),
             raw('<rect x="62" y="52" width="17" height="88" fill="#d3121b"/><rect x="113" y="52" width="17" height="88" fill="#d3121b"/>'
                 '<polygon points="62,52 80,52 130,140 112,140" fill="#ff3b3b"/>'))


@icon("org.chromium.webapk.af95c6d80000dea1b_v2")
def _():
    return P(solid('<rect x="34" y="62" width="124" height="86" rx="16"/>', "#6b6b72", "#26262b", (62, 148), .3),
             raw('<line x1="84" y1="62" x2="62" y2="34" stroke="#9a9aa3" stroke-width="5" stroke-linecap="round"/>'
                 '<line x1="108" y1="62" x2="132" y2="34" stroke="#9a9aa3" stroke-width="5" stroke-linecap="round"/>'
                 '<rect x="44" y="72" width="78" height="66" rx="10" fill="#9fd6ff"/>'
                 '<circle cx="142" cy="92" r="7" fill="#c8c8d0"/><circle cx="142" cy="116" r="7" fill="#c8c8d0"/>'))


# ----------------------------------------------------------------------------- tools / system
@icon("com.termux")
def _():
    return P(solid('<rect x="28" y="40" width="136" height="112" rx="14"/>', "#2a2a2a", "#0a0a0a", (40, 152), .25),
             raw('<rect x="28" y="40" width="136" height="112" rx="14" fill="none" stroke="#9a9a9a" stroke-width="5"/>'
                 + text(96, 116, "&gt;_", 54, "#6bea6b", family="DejaVu Sans Mono")))


@icon("flar2.devcheck")
def _():
    pins = "".join(f'<rect x="{68 + k * 18}" y="34" width="8" height="16" rx="2" fill="#aab"/><rect x="{68 + k * 18}" y="142" width="8" height="16" rx="2" fill="#aab"/>'
                   f'<rect x="34" y="{68 + k * 18}" width="16" height="8" rx="2" fill="#aab"/><rect x="142" y="{68 + k * 18}" width="16" height="8" rx="2" fill="#aab"/>'
                   for k in range(4))
    return P(raw(pins), solid('<rect x="48" y="48" width="96" height="96" rx="14"/>', "#6475d6", "#27338f", (48, 144), .4),
             raw('<rect x="68" y="68" width="56" height="56" rx="8" fill="#e8ecff"/>'
                 '<polyline points="78,98 92,112 116,82" fill="none" stroke="#2eaa5a" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>'))


@icon("com.gombosdev.ampere")
def _():
    return P(solid('<rect x="82" y="30" width="28" height="18" rx="5"/>', "#b8bcc4", "#7d828c", (30, 48), .2),
             solid('<rect x="58" y="42" width="76" height="124" rx="14"/>', "#6c717c", "#2b2f38", (42, 166), .35),
             solid('<rect x="68" y="84" width="56" height="72" rx="8"/>', "#7df07d", "#1fa83a", (84, 156), .3),
             raw('<polygon points="106,58 76,108 94,108 86,150 118,96 100,96" fill="#ffe14a" stroke="#c99a00" stroke-width="2" stroke-linejoin="round"/>'))


@icon("org.zwanoo.android.speedtest")
def _():
    return P(solid(CI, "#2c3a5e", "#0b1222", op=.3),
             raw('<defs><linearGradient id="arc" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#18d4ff"/><stop offset="1" stop-color="#9dffb0"/></linearGradient></defs>'
                 '<path d="M58 132 A46 46 0 1 1 134 132" fill="none" stroke="url(#arc)" stroke-width="11" stroke-linecap="round"/>'
                 '<line x1="96" y1="106" x2="126" y2="76" stroke="#fff" stroke-width="8" stroke-linecap="round"/>'
                 '<circle cx="96" cy="106" r="10" fill="#fff"/>'))


@icon("website.leifs.delta")
def _():
    tri = '<path fill-rule="evenodd" stroke-linejoin="round" stroke="#7a4cf0" stroke-width="10" d="M96 32 L160 152 L32 152 Z M96 84 L128 140 L64 140 Z"/>'
    return P(solid(tri, "#b08cff", "#5a2fd1", (32, 152), .4))


@icon("com.andrewkhandr.aspect")
def _():
    c = "".join(f'<path d="{p}" fill="none" stroke="#fff" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>' for p in
                ["M54 82 V58 H78", "M114 58 H138 V82", "M138 110 V134 H114", "M78 134 H54 V110"])
    return P(solid(SQ, "#58606e", "#232830", op=.35), raw(c))


@icon("com.nothing.smartcenter")
def _():
    dots = ""
    for i in (-44, -22, 0, 22, 44):
        for j in (i, -i):
            col = "#ff2a2a" if (i, j) == (44, -44) else "#fff"
            dots += f'<circle cx="{96 + i}" cy="{96 + j}" r="7" fill="{col}"/>'
    return P(solid(CI, "#3c3c3c", "#050505", op=.4), raw(dots))


@icon("com.nothing.weather")
def _():
    rays = "".join(f'<line x1="{120 + 36 * math.cos(math.radians(a)):.1f}" y1="{70 + 36 * math.sin(math.radians(a)):.1f}" '
                   f'x2="{120 + 46 * math.cos(math.radians(a)):.1f}" y2="{70 + 46 * math.sin(math.radians(a)):.1f}" '
                   'stroke="#ffcf3a" stroke-width="6" stroke-linecap="round"/>' for a in range(0, 360, 45))
    cloud = ('<path d="M60 150 A26 26 0 0 1 62 98 A36 36 0 0 1 128 94 A28 28 0 0 1 138 150 Z"/>')
    return P(raw(rays), solid('<circle cx="120" cy="70" r="28"/>', "#ffe45e", "#ff9c1a", (42, 98), .3),
             solid(cloud, "#ffffff", "#c3cdd8", (70, 150), .0))


# ----------------------------------------------------------------------------- food / shopping
@icon("com.Dominos")
def _():
    dots = lambda x0: "".join(f'<circle cx="{x0 + dx}" cy="{y}" r="6" fill="#fff"/>' for dx, y in [(-12, 74), (0, 96), (12, 118)])
    return P(raw('<g transform="translate(96 96) scale(1.22) rotate(-22) translate(-96 -96)">'
                 '<path d="M52 58 H96 V134 H52 A12 12 0 0 1 40 122 V70 A12 12 0 0 1 52 58 Z" fill="#0b6cb5"/>'
                 '<path d="M96 58 H140 A12 12 0 0 1 152 70 V122 A12 12 0 0 1 140 134 H96 Z" fill="#e31837"/>'
                 '<line x1="96" y1="58" x2="96" y2="134" stroke="#fff" stroke-width="4"/>'
                 + dots(68) + dots(124) + '</g>'))


@icon("com.application.zomato")
def _():
    return P(solid(SQ, "#f2616f", "#c91d2c", op=.45), raw(text(96, 108, "zomato", 29, style="italic")))


@icon("com.bigbasket.mobileapp")
def _():
    weave = "".join(f'<line x1="{x}" y1="96" x2="{x + (96 - x) * .0 + (x - 96) * .1:.0f}" y2="146" stroke="#c9323a" stroke-width="3"/>' for x in range(78, 120, 12))
    return P(solid(SQ, "#ea4a50", "#a31b24", op=.45),
             raw('<path d="M70 94 C70 54 122 54 122 94" fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round"/>'
                 '<polygon points="52,94 140,94 126,150 66,150" fill="#fff" stroke="#fff" stroke-width="6" stroke-linejoin="round"/>' + weave +
                 '<path d="M132 70 C150 62 156 74 148 84 C140 88 132 82 132 70 Z" fill="#6cc04a"/>'))


@icon("com.flipkart.android")
def _():
    bag = '<polygon points="58,78 134,78 146,152 46,152" stroke-linejoin="round" stroke="#f5b800" stroke-width="6"/>'
    return P(solid(SQ, "#4a95f7", "#1456cc", op=.45),
             raw('<path d="M76 78 C76 46 116 46 116 78" fill="none" stroke="#ffd633" stroke-width="9" stroke-linecap="round"/>'),
             solid(bag, "#ffe96b", "#f5b800", (78, 152), .3),
             raw(text(96, 136, "f", 62, "#1456cc")))


@icon("com.grofers.customerapp")
def _():
    return P(solid(SQ, "#ffe94d", "#f5c400", op=.5), raw(text(96, 106, "blinkit", 29, "#0c831f", style="italic")))


@icon("com.grofers.customerapp.lit")
def _():
    return P(solid(SQ, "#3a3a3a", "#050505", op=.35), raw(text(96, 106, "blinkit", 29, "#ffe94d", style="italic")))


@icon("com.poncho.eatclub")
def _():
    return P(solid(SQ, "#ffa24a", "#e55d00", op=.45),
             raw('<g fill="#fff"><rect x="56" y="48" width="7" height="38" rx="3.5"/><rect x="68" y="48" width="7" height="38" rx="3.5"/><rect x="80" y="48" width="7" height="38" rx="3.5"/>'
                 '<path d="M56 80 H87 V90 C87 100 80 104 74 104 H69 C63 104 56 100 56 90 Z"/><rect x="66" y="100" width="11" height="52" rx="5.5"/>'
                 '<path d="M118 48 C140 56 146 92 134 112 H118 Z"/><rect x="118" y="108" width="12" height="44" rx="6"/></g>'))


@icon("in.swiggy.android.toing")
def _():
    pin = '<path d="M96 36 C70 36 52 56 52 80 C52 112 96 158 96 158 C96 158 140 112 140 80 C140 56 122 36 96 36 Z"/>'
    return P(solid(SQ, "#ff8a4a", "#e44d12", op=.45), solid(pin, "#ffffff", "#ffe9dc", (36, 158), .0),
             raw('<circle cx="96" cy="80" r="19" fill="#ee5a1c"/>'))


@icon("com.olx.southasia")
def _():
    return P(solid(SQ, "#ffffff", "#dde2e8", op=.0),
             raw('<text x="38" y="114" font-size="54" font-weight="bold" font-family="DejaVu Sans">'
                 '<tspan fill="#002f34">O</tspan><tspan fill="#19c3b8">L</tspan><tspan fill="#f5b800">X</tspan></text>'))


# ----------------------------------------------------------------------------- finance / gov
@icon("com.phonepe.app")
def _():
    return P(solid(SQ, "#8a4fd6", "#4a1d96", op=.45),
             raw('<g fill="none" stroke="#fff" stroke-width="12" stroke-linecap="round" stroke-linejoin="round">'
                 '<line x1="54" y1="68" x2="138" y2="68"/><line x1="66" y1="68" x2="66" y2="142"/>'
                 '<path d="M66 104 C66 86 112 86 112 104 L112 142"/><line x1="96" y1="46" x2="118" y2="34"/></g>'))


@icon("com.kotak811mobilebankingapp.instantsavingsupiscanandpayrecharge")
def _():
    return P(solid(SQ, "#f2474f", "#bd0f19", op=.45), raw(text(96, 116, "811", 56)))


@icon("org.altruist.BajajExperia")
def _():
    return P(solid(SQ, "#ffffff", "#dde3ec", op=.0),
             raw(text(96, 98, "BAJAJ", 34, "#0b4a9f") + text(96, 128, "FINANCE", 22, "#f58220")))


@icon("com.vaibhavkalpe.android.khatabook")
def _():
    return P(solid(SQ, "#3fa7e8", "#0f5fa8", op=.45),
             raw('<path d="M96 72 C80 60 56 60 42 68 V140 C58 132 80 132 96 144 Z" fill="#fff"/>'
                 '<path d="M96 72 C112 60 136 60 150 68 V140 C134 132 112 132 96 144 Z" fill="#dbe9f7"/>'
                 '<line x1="96" y1="72" x2="96" y2="144" stroke="#9db8d6" stroke-width="3"/>'
                 + text(122, 118, "₹", 40, "#0f5fa8")))


@icon("com.citrus.citruspay")
def _():
    return P(solid('<rect x="34" y="62" width="124" height="90" rx="18"/>', "#8a63d8", "#43239b", (62, 152), .4),
             raw('<rect x="34" y="62" width="124" height="26" rx="14" fill="#000" opacity=".12"/>'
                 '<circle cx="132" cy="108" r="14" fill="#ffd54a"/><circle cx="132" cy="108" r="7" fill="#e0a800"/>'))


@icon("com.digilocker.android")
def _():
    return P(raw('<path d="M68 96 V72 C68 44 124 44 124 72 V96" fill="none" stroke="#c8d2dc" stroke-width="14" stroke-linecap="round"/>'),
             solid('<rect x="50" y="90" width="92" height="68" rx="14"/>', "#3d8be8", "#1648a0", (90, 158), .4),
             raw('<circle cx="96" cy="118" r="10" fill="#fff"/><rect x="92" y="120" width="8" height="22" rx="3" fill="#fff"/>'))


@icon("com.nic.mparivahan")
def _():
    return P(solid(SQ, "#4a86e0", "#173f8e", op=.45),
             raw('<circle cx="96" cy="96" r="44" fill="none" stroke="#fff" stroke-width="11"/><circle cx="96" cy="96" r="12" fill="#fff"/>'
                 '<line x1="52" y1="96" x2="84" y2="96" stroke="#fff" stroke-width="11"/><line x1="108" y1="96" x2="140" y2="96" stroke="#fff" stroke-width="11"/>'
                 '<line x1="96" y1="108" x2="96" y2="140" stroke="#fff" stroke-width="11"/>'))


@icon("cris.org.in.prs.ima")
def _():
    return P(solid('<rect x="44" y="36" width="104" height="116" rx="32"/>', "#3a7be0", "#133a86", (36, 152), .4),
             raw('<rect x="58" y="54" width="76" height="46" rx="12" fill="#d3e8ff"/><line x1="96" y1="54" x2="96" y2="100" stroke="#5b86bd" stroke-width="4"/>'
                 '<circle cx="68" cy="124" r="10" fill="#ffe66a"/><circle cx="124" cy="124" r="10" fill="#ffe66a"/>'
                 '<rect x="82" y="116" width="28" height="12" rx="4" fill="#0e2c66"/>'
                 '<rect x="38" y="158" width="116" height="7" rx="3" fill="#8890a0"/>'))


# ----------------------------------------------------------------------------- games
@icon("com.pubg.imobile")
def _():
    helmet = '<path d="M40 112 C40 66 72 44 98 44 C128 44 154 70 154 112 Z"/>'
    return P(solid(SQ, "#4a4a4a", "#17181a", op=.3),
             solid(helmet.replace('<path', '<path transform="translate(0 4)"'), "#9bab63", "#4f5f2b", (44, 112), .35),
             raw('<rect x="32" y="112" width="132" height="14" rx="7" fill="#3f4c22"/>'
                 '<path d="M64 76 C74 66 90 64 96 74 C84 78 74 84 64 96 Z" fill="#5f6f36"/>'
                 '<path d="M110 62 C124 62 138 74 140 88 C128 82 118 76 110 62 Z" fill="#3a471f"/>'
                 '<path d="M48 126 C48 144 60 150 72 150 L72 126 Z" fill="#2c3417"/>'))


@icon("jp.pokemon.pokemonunite")
def _():
    return P(solid(CI, "#ffffff", "#c8cdd4", op=.0),
             raw('<defs><linearGradient id="pr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff5a50"/><stop offset="1" stop-color="#c0161a"/></linearGradient>'
                 '<clipPath id="pc"><circle cx="96" cy="96" r="66"/></clipPath></defs>'
                 '<g clip-path="url(#pc)"><rect x="20" y="20" width="152" height="76" fill="url(#pr)"/><rect x="20" y="96" width="152" height="76" fill="#f2f2f2"/>'
                 '</g>'
                 '<circle cx="96" cy="96" r="66" fill="none" stroke="#222" stroke-width="8"/>'
                 '<line x1="30" y1="96" x2="162" y2="96" stroke="#222" stroke-width="9"/>'
                 '<circle cx="96" cy="96" r="20" fill="#fff" stroke="#222" stroke-width="8"/><circle cx="96" cy="96" r="8" fill="#ddd"/>'))


@icon("com.wildspike.wormszone")
def _():
    pts = [(48, 134), (66, 146), (90, 148), (114, 140), (130, 120), (130, 96), (116, 76)]
    body = "".join(f'<circle cx="{x}" cy="{y}" r="{15 + k}" fill="url(#wm)"/>' for k, (x, y) in enumerate(pts))
    d = vg("wm", "#a2f56e", "#27a31a", (60, 160))
    return P(solid(SQ, "#2ea1b3", "#0e4d5c", op=.4),
             (d, body + '<circle cx="110" cy="70" r="9" fill="#fff"/><circle cx="130" cy="74" r="9" fill="#fff"/>'
                        '<circle cx="112" cy="72" r="4" fill="#111"/><circle cx="132" cy="76" r="4" fill="#111"/>'))


@icon("com.nordcurrent.flyingfever")
def _():
    return P(solid(CI, "#69cdff", "#1d78cf", op=.4),
             solid('<path d="M66 104 A22 22 0 0 1 72 62 A28 28 0 0 1 120 60 A24 24 0 0 1 128 104 Z"/>', "#ffffff", "#e3e3e3", (50, 104), .0),
             raw('<rect x="66" y="98" width="62" height="30" rx="6" fill="#fff"/><rect x="66" y="112" width="62" height="6" fill="#e04040"/>'))


# ----------------------------------------------------------------------------- archived / cloud apps
@icon("com.reddit.frontpage")
def _():
    return P(solid(CI, "#ff6a33", "#e03d00", op=0),
             raw('<path d="M96 80 C98 64 106 54 118 50" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round"/>'
                 '<circle cx="122" cy="48" r="9" fill="#fff"/><circle cx="48" cy="104" r="12" fill="#fff"/><circle cx="144" cy="104" r="12" fill="#fff"/>'
                 '<ellipse cx="96" cy="112" rx="46" ry="33" fill="#fff"/>'
                 '<circle cx="78" cy="106" r="9" fill="#ff4500"/><circle cx="114" cy="106" r="9" fill="#ff4500"/>'
                 '<path d="M76 124 Q96 140 116 124" fill="none" stroke="#ff4500" stroke-width="5" stroke-linecap="round"/>'))


@icon("com.spotify.music")
def _():
    arcs = [("M50 78 Q98 58 144 84", 13), ("M58 104 Q98 90 136 106", 11), ("M66 128 Q98 118 128 130", 9)]
    return P(solid(CI, "#2fe06a", "#14a84a", op=0),
             raw("".join(f'<path d="{d}" fill="none" stroke="#111" stroke-width="{w}" stroke-linecap="round"/>' for d, w in arcs)))


@icon("com.ubercab")
def _():
    return P(solid(SQ, "#2e2e2e", "#000000", op=0),
             raw('<path d="M68 54 V104 A28 28 0 0 0 124 104 V54" fill="none" stroke="#fff" stroke-width="18"/>'))


@icon("com.utorrent.client")
def _():
    return P(solid(CI, "#ffffff", "#e6e6e6", op=0),
             raw('<circle cx="96" cy="96" r="62" fill="none" stroke="#5fb028" stroke-width="10"/>' + text(96, 126, "&#181;", 100, "#5fb028")))


@icon("com.google.android.apps.nbu.paisa.user")
def _():
    return P(solid(CI, "#ffffff", "#e8eaee", op=0),
             raw('<g transform="rotate(-32 96 96)"><rect x="42" y="92" width="58" height="34" rx="17" fill="#4285f4"/>'
                 '<rect x="62" y="62" width="58" height="34" rx="17" fill="#34a853"/><rect x="92" y="78" width="58" height="34" rx="17" fill="#ea4335"/>'
                 '<rect x="72" y="104" width="58" height="34" rx="17" fill="#fbbc04"/></g>'))


@icon("com.acko.android")
def _():
    return P(solid(SQ, "#8a4af2", "#4b20b5", op=0), raw(text(96, 112, "acko", 46)))


@icon("com.jio.myjio")
def _():
    return P(solid(CI, "#ee1c2e", "#b3081b", op=0), raw(text(96, 116, "Jio", 62, family="DejaVu Sans")))


@icon("com.tuzkituan.metrov")
def _():
    return P(solid(CI, "#2a2a2a", "#000000", op=0),
             raw('<rect x="56" y="56" width="38" height="38" fill="#555"/><rect x="98" y="56" width="38" height="38" fill="#fff"/>'
                 '<rect x="56" y="98" width="38" height="38" fill="#fff"/>'))


# ----------------------------------------------------------------------------- sharp redraws of the 72px originals
def lg(i, top, bot, ys, xs=None):
    x = f'x1="{xs[0]}" x2="{xs[1]}"' if xs else 'x1="0" x2="0"'
    return (f'<linearGradient id="{i}" gradientUnits="userSpaceOnUse" {x} y1="{ys[0]}" y2="{ys[1]}">'
            f'<stop offset="0" stop-color="{top}"/><stop offset="1" stop-color="{bot}"/></linearGradient>')


@icon("com.maxmpz.audioplayer")
def _():
    dots = "".join(f'<circle cx="{62 + dx}" cy="{126 + dy}" r="2" fill="#7a7a7a"/>'
                   for dx in range(-28, 29, 7) for dy in range(-28, 29, 7) if dx * dx + dy * dy <= 27 * 27)
    ticks = "".join(f'<rect x="{x}" y="82" width="2" height="8" fill="#9a9a9a"/>' for x in (66, 96, 126, 148))
    d = lg("rb", "#767676", "#262626", (60, 160)) + lg("sl", "#e2e2e2", "#6c6c6c", (112, 134)) + lg("sp", "#3a3a3a", "#1c1c1c", (94, 158))
    b = ('<line x1="38" y1="30" x2="156" y2="62" stroke="#8d8d8d" stroke-width="3.5" stroke-linecap="round"/><circle cx="38" cy="30" r="3.5" fill="#b4b4b4"/>'
         '<rect x="18" y="60" width="156" height="100" rx="9" fill="url(#rb)"/>'
         '<rect x="30" y="70" width="132" height="24" rx="3" fill="#2b2b2b" stroke="#8a8a8a" stroke-width="1.5"/>'
         '<rect x="34" y="74" width="124" height="16" fill="#4d4d4d"/>' + ticks +
         '<rect x="48" y="68" width="3" height="28" fill="#d63a2a"/>'
         '<circle cx="62" cy="126" r="32" fill="url(#sp)" stroke="#5c5c5c" stroke-width="3"/>' + dots +
         '<rect x="108" y="112" width="54" height="22" rx="3" fill="url(#sl)" stroke="#222" stroke-width="1.5"/>')
    return d, b


@icon("com.google.android.apps.nbu.files", "com.estrongs.android.pop")
def _():
    d = (lg("fb", "#f9cd50", "#d89a14", (42, 152)) + lg("ff", "#ffe27f", "#e0a21a", (76, 160)) +
         lg("p1", "#86cf55", "#2b781e", (55, 95)) + lg("p2", "#a6d3f5", "#eaf5ff", (51, 93)))
    b = ('<path d="M20 50 Q20 42 28 42 H66 Q72 42 76 48 L84 58 H164 Q172 58 172 66 V152 H20 Z" fill="url(#fb)"/>'
         '<g transform="rotate(-9 70 78)"><rect x="40" y="52" width="54" height="46" fill="#fff"/><rect x="43" y="55" width="48" height="40" fill="url(#p1)"/>'
         '<path d="M43 88 L58 74 L70 84 L82 70 L91 80 V95 H43 Z" fill="#2f6e22" opacity=".7"/></g>'
         '<g transform="rotate(4 128 76)"><rect x="100" y="48" width="58" height="48" fill="#fff"/><rect x="103" y="51" width="52" height="42" fill="url(#p2)"/>'
         '<ellipse cx="124" cy="80" rx="14" ry="5" fill="#fff"/></g>'
         '<rect x="20" y="76" width="152" height="84" rx="7" fill="url(#ff)"/><rect x="20" y="76" width="152" height="3" rx="1.5" fill="#fff" opacity=".45"/>')
    return d, b


@icon("com.android.stk")
def _():
    d = lg("sc", "#3d90e4", "#174c9a", (22, 170)) + lg("sg", "#ffe86e", "#d6a200", (76, 140))
    lines = "".join(f'<line x1="{x}" y1="118" x2="{x}" y2="140" stroke="#9c7600" stroke-width="2.5"/>' for x in (89, 104, 119))
    b = ('<path d="M44 22 H128 L158 52 V170 H44 Z" fill="url(#sc)" stroke="#174c9a" stroke-width="4" stroke-linejoin="round"/>'
         '<rect x="62" y="76" width="84" height="64" rx="10" fill="url(#sg)" stroke="#a67c00" stroke-width="2.5"/>'
         '<rect x="78" y="86" width="52" height="24" rx="4" fill="none" stroke="#9c7600" stroke-width="2.5"/>'
         '<line x1="104" y1="86" x2="104" y2="110" stroke="#9c7600" stroke-width="2.5"/>'
         '<line x1="62" y1="118" x2="146" y2="118" stroke="#9c7600" stroke-width="2.5"/>' + lines)
    return d, b


@icon("com.google.android.apps.docs.editors.docs")
def _():
    d = lg("qb", "#5cb4ea", "#1b78c2", (32, 150))
    fan = "".join(f'<rect x="56" y="40" width="76" height="116" rx="6" fill="{c}" transform="rotate({a} 70 156)"/>'
                  for c, a in [("#e2563b", -38), ("#f39c2a", -27), ("#f4d21f", -16), ("#8dc63f", -5)])
    b = fan + '<rect x="84" y="30" width="84" height="120" rx="6" fill="url(#qb)" transform="rotate(8 126 150)"/>'
    return d, b


@icon("com.nothing.gallery")
def _():
    d = (lg("gf", "#8c8c92", "#3c3c42", (32, 160)) +
         '<linearGradient id="gp" gradientUnits="userSpaceOnUse" x1="52" y1="140" x2="140" y2="52">'
         '<stop offset="0" stop-color="#3f1a86"/><stop offset=".45" stop-color="#c0307c"/><stop offset=".8" stop-color="#ff8a3c"/><stop offset="1" stop-color="#ffd36b"/></linearGradient>')
    b = ('<rect x="30" y="30" width="132" height="132" rx="4" fill="url(#gf)"/>'
         '<rect x="44" y="44" width="104" height="104" fill="#26262b"/>'
         '<rect x="48" y="48" width="96" height="96" fill="none" stroke="#e2e2e6" stroke-width="4"/>'
         '<rect x="52" y="52" width="88" height="88" fill="url(#gp)"/>'
         '<path d="M58 132 C78 124 98 104 132 62" fill="none" stroke="#fff" stroke-opacity=".38" stroke-width="9" stroke-linecap="round"/>')
    return d, b


@icon("com.github.android")
def _():
    return P(solid(SQ, "#2b3137", "#0d1117", op=0),
             raw('<g fill="#fff"><ellipse cx="96" cy="96" rx="50" ry="44"/><polygon points="52,86 56,40 90,62"/><polygon points="140,86 136,40 102,62"/>'
                 '<circle cx="68" cy="136" r="12"/><circle cx="96" cy="142" r="12"/><circle cx="124" cy="136" r="12"/><rect x="62" y="110" width="68" height="30"/></g>'))


@icon("com.nothing.soundrecorder")
def _():
    d = lg("rr", "#e8423d", "#a31412", (24, 168)) + lg("rm", "#ffffff", "#cfcfcf", (52, 108))
    grill = "".join(f'<line x1="82" y1="{y}" x2="110" y2="{y}" stroke="#c43a35" stroke-width="2.5"/>' for y in (66, 74, 82, 90))
    b = ('<circle cx="96" cy="96" r="72" fill="url(#rr)"/><circle cx="96" cy="96" r="66" fill="none" stroke="#f2f2f2" stroke-width="5"/>'
         '<rect x="78" y="48" width="36" height="62" rx="18" fill="url(#rm)"/>' + grill +
         '<path d="M68 96 C68 126 124 126 124 96" fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round"/>'
         '<line x1="96" y1="122" x2="96" y2="142" stroke="#fff" stroke-width="7"/><line x1="78" y1="143" x2="114" y2="143" stroke="#fff" stroke-width="7" stroke-linecap="round"/>')
    return d, b


# ----------------------------------------------------------------------------- run
TARGET = 176   # content size in the 192px canvas (matches the stock dock icons)


def render(pkg):
    defs, body = D[pkg]()
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192"><defs>{defs}</defs>{body}</svg>'
    big = Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode(), output_width=768, output_height=768))).convert("RGBA")
    bb = big.getchannel("A").point(lambda v: 255 if v >= 128 else 0).getbbox()
    crop = big.crop(bb)
    k = TARGET / max(crop.size)
    crop = crop.resize((max(1, round(crop.width * k)), max(1, round(crop.height * k))), Image.LANCZOS)
    im = Image.new("RGBA", (192, 192), (0, 0, 0, 0))
    im.paste(crop, ((192 - crop.width) // 2, (192 - crop.height) // 2 - 2), crop)
    a = im.getchannel("A").filter(ImageFilter.GaussianBlur(3)).point(lambda v: int(v * .45))
    sh = Image.new("RGBA", (192, 192), (0, 0, 0, 0))
    sh.putalpha(a)
    sh = ImageChops.offset(sh, 0, 4)
    Image.alpha_composite(sh, im).save(os.path.join(OUT, pkg + ".png"))


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    todo = sys.argv[1:] or sorted(D)
    bad = []
    for p in todo:
        try:
            render(p)
        except Exception as e:
            bad.append((p, repr(e)[:120]))
    print(f"drew {len(todo) - len(bad)} icons", bad if bad else "")
